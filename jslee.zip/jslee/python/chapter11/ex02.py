# 덧셈 연산 함수
def addition(n1, n2):
	print('덧셈 연산 결과 : ')
	print(int(n1) + int(n2))
	
	return

# 뺄셈 연산 함수
def subtraction(n1, n2):
	print('뺄셈 연산 결과 : ')
	print(int(n1) - int(n2))
	
	return
	
# 곱셈 연산 함수		
def multiplication(n1, n2):
	print('곱셈 연산 결과 : ')
	print(int(n1) * int(n2))
	
	return
	
# 나눗셈 연산 함수			
def division(n1, n2):
	print('나눗셈 연산 결과 : ')
	print(int(n1) / int(n2))
	
	return

firstNum = input()
secondNum = input()

addition(firstNum, secondNum)
subtraction(firstNum, secondNum)
multiplication(firstNum, secondNum)
division(firstNum, secondNum)