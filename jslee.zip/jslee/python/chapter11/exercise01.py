class SmallestHeight(Exception):
		def __init__(self, e):
			super().__init__('앗! 이런!! 죄송합니다. 신장 미달입니다. {0}cm'.format(e))

def checkHeight(height):
		if height >= sHeight:
			return height
		else:
			raise SmallestHeight(height)
			
if __name__ == '__main__':

		playFalg = True
		while playFalg:
			sHeight = int(input('\n놀이기구 탑승 가능한 신장을 입력하세요. : '))
			
			print('\n아래의 번호를 선택하세요.')
			print('1. 놀이기구 운영,\t2 놀이기구 운영 종료')
			
			userInputNum = int(input())
			
			if userInputNum == 1:
				try:
					print('아이 신장을 측정합니다.')
					childHeight = int(input())
					result = checkHeight(childHeight)
				except SmallestHeight as e:
					print('{0}'.format(e))
				else:
					print('아이의 신장은 {0}cm 입니다. 즐거운 시간되세요.'.format(result))
			
			else:
				playFalg = False
				print('영업 종료입니다. 내일 오세요.')