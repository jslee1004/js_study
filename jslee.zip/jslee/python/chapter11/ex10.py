def cal(f, s):
		if(s != 0):
			print('덧셈 연산 결과 : {0}'.format(firstNum + secondNum))
			print('나눗셈 연산 결과 : {0}'.format(firstNum / secondNum))
		else:
			raise Exception('\'0\'으로 나눌 수 없습니다.')
		
if __name__ == '__main__':
		firstNum = int(input('정수를 입력하세요. : '))
		secondNum = int(input('정수를 입력하세요. : '))
		
		try:
				cal(firstNum, secondNum)
		except Exception as e:
				print('Error : {0}'.format(e))