firstNum = int(input())
secondNum = int(input())

try:
	print('나눗셈 연산 결과 : {0}'.format(firstNum / secondNum))
except:
	print('예외 발생!!')
else:
	print('정상 실행!!')
finally:
	print('항상 실행!!')

print('덧셈 연산 결과 : {0}'.format(firstNum + secondNum))
	
print('\n사용자가 입력한 데이터: {0}과 {1}'.format(firstNum, secondNum))