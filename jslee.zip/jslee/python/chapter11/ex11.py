class NotUsefulNumberException(Exception):
		def __init__(self, data1, data2):
				super().__init__('사용할 수 없는 데이터 입니다.\t{0}, {1}'.format(data1, data2))


def cal(n1, n2):
		if n2 != 0:
			print('{0} + {1} = {2}'.format(n1, n2, (n1 + n2)))
			print('{0} / {1} = {2}'.format(n1, n2, (n1 / n2)))
			
		else:
			raise NotUsefulNumberException(n1, n2)


if __name__ == '__main__':
		
		print('첫 번째 숫자를 입력하세요.')
		firstNum = int(input());
		print('두 번째 숫자를 입력하세요.')
		secondNum = int(input());
		
		try:		
				cal(firstNum, secondNum)
		except NotUsefulNumberException as e:
				print('예외 발생!\t{0}'.format(e))
		else:
				print('정상 실행!')