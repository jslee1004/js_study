# 1부터 10까지 정수의 합
sum = 0
for i in range(1, 11, 1):
    sum = sum + i

print(sum)

# 1부터 10까지 정수의 합
sum = 0
for i in range(1, 11):
    sum = sum + i

print(sum)

# 0부터 10까지 정수의 합
sum = 0
for i in range(0, 11):
    sum = sum + i

print(sum)

# 0부터 10까지 정수의 합
sum = 0
for i in range(11):
    sum = sum + i

print(sum)

for i in range(10, 1, -1):
	print('i = ', i)

for i in range(10, 1, -2):
	print('i = ', i)

for i in range(10, 1, -3):
	print('i = ', i)

num = 5
for i in range(9, 0, -1):
	print(num, end = "")
	print(" * ", end = "")
	print(i, end = "")
	print(" = ", end = "")
	print(num * i, end = "")
	print()