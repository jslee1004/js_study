userInt = int(input('원하는 구구단을 입력하세요.'))

for i in range(1, 10, 1):
	print(userInt, end='')
	print(' * ', end='')
	print(i, end='')
	print(' = ', end='')
	print(userInt * i)