# while문을 이용한 0부터 10까지 정수의 합
cNum = 0
sNum = 0;
while cNum < 11:
    sNum = sNum + cNum
    cNum = cNum + 1
	
print(sNum)

# continue
for i in range(1, 10):
    if (i % 2) == 1:
        continue
		
    print(i)
	
# break
for i in range(1, 10):
    if (i > 5) == 1:
        break
		
    print(i)
	
# 구구단(for문)
num = 5
for i in range(1, 10, 1):
	print(num, end = "")
	print(" * ", end = "")
	print(i, end = "")
	print(" = ", end = "")
	print(num * i, end = "")
	print()

# 구구단(while문)
num = 5
i = 1
while i < 10:
	print(num, end = "")
	print(" * ", end = "")
	print(i, end = "")
	print(" = ", end = "")
	print(num * i, end = "")
	print()
	i = i + 1