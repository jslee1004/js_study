# 2단 부터 9단까지 구구단이 실행됩니다.

for i in range(1, 10, 1):
    for j in range(2, 10, 1):
        print(j, end = "")
        print(" * ", end = "")
        print(i, end = "")
        print(" = ", end = "")
        print(i * j, end = "\t")
    print()
