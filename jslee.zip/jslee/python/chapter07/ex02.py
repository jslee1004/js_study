# 1부터 10까지 정수의 합
sum = 0
for i in range(1, 11, 1):
    sum = sum + i

print(sum)

# 1부터 10까지 홀수의 합
sum = 0
for i in range(1, 11, 2):
    sum = sum + i

print(sum)

# 1부터 100까지 짝수의 합
sum = 0
for i in range(0, 101, 2):
    sum = sum + i

print(sum)

# 1부터 100까지 홀수의 합
sum = 0
for i in range(1, 101, 2):
    sum = sum + i

print(sum)

# 변수 num의 값으로 구구단이 실행됩니다.
num = 2
for i in range(1, 10, 1):
    print(num, end = "")
    print(" * ", end = "")
    print(i, end = "")
    print(" = ", end = "")
    print(num * i, end = "")
    print()

