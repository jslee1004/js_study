# 2단 부터 9단까지 구구단이 실행됩니다.

for i in range(2, 10, 1):
    print(i, end = "")
    print("단", end = "")
    print()
    for j in range(1, 10, 1):
        print(i, end = "")
        print(" * ", end = "")
        print(j, end = "")
        print(" = ", end = "")
        print(i * j, end = "")
        print()
    print()