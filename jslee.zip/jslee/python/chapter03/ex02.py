print(type(123))

print('----------------')

iNum = 123
print(type(iNum))