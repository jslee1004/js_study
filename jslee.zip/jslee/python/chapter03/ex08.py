boolVar1 = True
boolVar2 = False

print(type(boolVar1))
print(type(boolVar2))

print(type(3 > 5))
print(type(3 < 5))