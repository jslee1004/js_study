str1 = 'h'
str2 = 'hello'
print(type(str1))
print(type(str2))

print('---------------')

print(type('h'))
print(type('hello'))

print('---------------')

print(type('1'))
print(type('123456789'))
