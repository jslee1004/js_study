str1 = 'hello'
str2 = ' '
str3 = 'world'
str4 = '      hello world      '
str5 = 'korea, usa, japan, china, russia'
str6 = 'KOREA, USA, JAPAN, CHINA, RUSSIA'

# find() 메서드
print('\nfind() -------------')
print(str1.find('he'))
print(str1.find('lo'))
print(str1.find('ss'))

# count() 메서드
print('\ncount() -------------')
print(str1.count('e'))
print(str1.count('l'))

# replace() 메서드
print('\nreplace() -------------')
print(str3)
print(str3.replace('world', 'python'))

# startswith() 메서드
print('startswith() -------------')
print(str1.startswith('he'))
print(str1.startswith('el'))

# endswith() 메서드
print('endswith() -------------')
print(str1.endswith('lo'))
print(str1.endswith('ell'))

# strip() 메서드
print('\nstrip() -------------')
print(str4)
print(str4.strip())

# split() 메서드
print('\nsplit() -------------')
print(str5.split(','))

# upper() 메서드
print('\nupper() -------------')
print(str5.upper())

# lower() 메서드
print('\nlower() -------------')
print(str6.lower())