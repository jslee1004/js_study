# 지문을 py변수에 담음
py = 'Python is an interpreted, high-level, general-purpose programming language. Created by Guido van Rossum and first released in 1991, Python has a design philosophy that emphasizes code readability, notably using significant whitespace. It provides constructs that enable clear programming on both small and large scales. Van Rossum led the language community until stepping down as leader in July 2018.'

# find()를 이용해서 'Guido van Rossum'의 인덱스를 참음
print(py.find('Guido van Rossum'))

# count()를 이용해서 'Python'의 횟수를 찾음
print(py.count('Python'))

# replace()를 이용해서 'Python'를 '파이썬'으로 변경함
print(py.replace('Python', '파이썬'))

# split()를 이용해서 공백문자(' ')를 이용해서 모든 문자열을 문자로 구분함
print(py.split(' '))

# lower()를 이용해서 소문자로 변경함
print(py.lower())

# upper()를 이용해서 대문자로 변경함
print(py.upper())