iNum = 3.14
print(type(iNum))

iNumLarge = 123.123456789012345670
print(iNumLarge)
