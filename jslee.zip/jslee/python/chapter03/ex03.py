iNum1 = -1234567890
iNum2 = 0
iNum3 = 1234567890

print(type(iNum1))
print(type(iNum2))
print(type(iNum3))

print('---------------')

print(type(-123))
print(type(0))
print(type(123))

print('---------------')

print(type(10+100))
print(type(10-100))
print(type(10*100))
print(type(10/100))
