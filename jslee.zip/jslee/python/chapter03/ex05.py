iNum1 = 123.456
iNum2 = 0.0
iNum3 = 123.456

print(type(iNum1))
print(type(iNum2))
print(type(iNum3))

print('---------------')

print(type(123.456))
print(type(0.0))
print(type(-123.456))

print('---------------')

print(type(10+123.456))
print(type(10-123.456))
print(type(10*123.456))
print(type(10/123.456))