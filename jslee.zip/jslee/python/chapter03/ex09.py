var1 = '123'
var2 = 456

# 예외(에러) 발생
#print(var1 + var2)

# 문자(열)를 정수로 변경
print(int(var1) + var2)

# 정수를 문자(열)로 변경
print(var1 + str(var2))

print(int('hello'))
