#변수에 정수를 정장해 봅니다.
myNum = 10
print("myNum: ", myNum)
myNum = 20
print("myNum: ", myNum)

#변수를 이용한 사칙연산
firstNum = 100
secondNum = 200
print("firstNum + secondNum: ", firstNum + secondNum)
print("firstNum - secondNum: ", firstNum - secondNum)
print("firstNum * secondNum: ", firstNum * secondNum)
print("firstNum / secondNum: ", firstNum / secondNum)

#변수에 실수를 저장하고 사칙연산을 합니다.
ratNum = 0.1
print("ratNum + 0.5: ", ratNum + 0.5)
print("ratNum - 0.5: ", ratNum - 0.5)
print("ratNum * 0.5: ", ratNum * 0.5)
print("ratNum / 0.5: ", ratNum / 0.5)

#변수에 문자를 저장합니다.
char1 = 'h'
char2 = 'e'
char3 = 'l'
char4 = 'o'
print("char1: ", char1)
print("char2: ", char2)
print("char3: ", char3)
print("char4: ", char4)
print(char1, char2, char3, char3, char4)

#변수에 문자열을 저장합니다.
str1 = "hello"
str2 = " "
str3 = "Python"
print("str1:", str1)
print("str2:", str2)
print("str3:", str3)
print(str1, str2, str3)

#주석은 실행하지 않아요.
var1 = 100
var2 = 200
print("var1 + var2: ", var1 + var2)
#print("var1 * var2: ", var1 * var2)

