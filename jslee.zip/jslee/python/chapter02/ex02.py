#변수 선언 및 초기화
myMoney = 1000

#변수 호출
print(myMoney)

#변수 데이터 변경
myMoney = 1500

#변수 호출
print(myMoney)

#아빠 용돈
papaMoney = 10000
print("아빠 용돈 : ", papaMoney)

#엄마 용돈
momMoney = 15000
print("엄마 용돈 : ", momMoney)

print("아빠, 엄마 용돈이 10% 인상됐어요.")
papaMoney = 11000
print("아빠 용돈 : ", papaMoney)

momMoney = 16500
print("엄마 용돈 : ", momMoney)
