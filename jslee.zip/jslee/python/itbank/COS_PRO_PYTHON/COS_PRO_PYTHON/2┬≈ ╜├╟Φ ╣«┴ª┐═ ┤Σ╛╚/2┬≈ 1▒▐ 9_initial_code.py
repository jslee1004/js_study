'''

구성은

1. 문제 설명
2. 원본 문제(코드)
3. 강사 답안
4. 주최측 답안

순으로 되어있습니다.

빈칸채우기와 한 줄 수정의 경우 
강사 답안과 주최 답안이 유사 / 동일할 수 있습니다.



#문제9
주어진 비밀번호가 안전한지 아닌지 판단하려합니다. 비밀번호의 안전 여부는 다음 규칙으로 판단합니다.

* 연속된 3자리 이상의 알파벳 혹은 숫자를 사용할 수 없습니다. (abc, cba, 012, 987 등)

비밀번호에 사용할 문자열 password가 매개변수로 주어질 때, 
주어진 문자열이 위 규칙에 맞으면 true를, 
맞지 않으면 false를 return 하도록 solution 함수를 작성했습니다. 
그러나, 코드 일부분이 잘못되어있기 때문에, 
몇몇 입력에 대해서는 올바르게 동작하지 않습니다. 
주어진 코드에서 _**한 줄**_만 변경해서 모든 입력에 대해 올바르게 동작하도록 수정하세요.

---
#####매개변수 설명
비밀번호에 사용할 문자열 password가 solution 함수의 매개변수로 주어집니다.
* password는 알파벳 소문자와 숫자로만 이루어진 문자열입니다.
* password의 길이는 5 이상 20 이하입니다.

---
#####return 값 설명
주어진 문자열이 주어진 규칙에 맞으면 true를, 맞지 않으면 false를 return 해주세요.

---
#####예시

| password    | return |
|-------------|--------|
| "cospro890" | true   |
| "cba323"    | false  |

#####예시 설명
예시 #1
주어진 문자열에는 연속된 3자리 이상의 문자열 혹은 숫자가 없습니다.

예시 #2
"cba"가 연속된 3자리 문자열이므로 주어진 규칙에 맞지 않습니다.

def solution(password):
    length = len(password)
    for i in range(length - 2):
        first_check = ord(password[i + 1]) - ord(password[i])
        second_check = ord(password[i]) - ord(password[i+1])
        if first_check == second_check and (first_check == 1 or first_check == -1):
            return False
    return True

#아래는 테스트케이스 출력을 해보기 위한 코드입니다. 아래 코드는 잘못된 부분이 없으니, solution함수만 수정하세요.
password1 = "cospro890"
ret1 = solution(password1)

#[실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
print("solution 함수의 반환 값은", ret1, "입니다.")

password2 = "cba323"
ret2 = solution(password2)

#[실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
print("solution 함수의 반환 값은", ret2, "입니다.")


'''

def solution(password):
    length = len(password)
    for i in range(length - 2):
        first_check = ord(password[i + 1]) - ord(password[i])
        second_check = ord(password[i]) - ord(password[i - 1])
        # 다음글자와의 간격을 체크하는 first_check를 보면
        # +1번째 인덱스에서 +0번째 인덱스를 빼는 과정입니다.
        # 그렇기 때문에 이전글자와의 간격을 체크하는 second_check에서는
        # +0번째 인덱스에서 -1번째 인덱스를 빼야 합니다.
        if first_check == second_check and (first_check == 1 or first_check == -1):
            return False
    return True

#아래는 테스트케이스 출력을 해보기 위한 코드입니다. 아래 코드는 잘못된 부분이 없으니, solution함수만 수정하세요.
password1 = "cospro890"
ret1 = solution(password1)

#[실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
print("solution 함수의 반환 값은", ret1, "입니다.")

password2 = "cba323"
ret2 = solution(password2)

#[실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
print("solution 함수의 반환 값은", ret2, "입니다.")

'''
주최 제공 답안
def solution(password):
    length = len(password)
    for i in range(length - 2):
        first_check = ord(password[i + 1]) - ord(password[i])
        second_check = ord(password[i + 2]) - ord(password[i+1])
        if first_check == second_check and (first_check == 1 or first_check == -1):
            return False
    return True
'''
