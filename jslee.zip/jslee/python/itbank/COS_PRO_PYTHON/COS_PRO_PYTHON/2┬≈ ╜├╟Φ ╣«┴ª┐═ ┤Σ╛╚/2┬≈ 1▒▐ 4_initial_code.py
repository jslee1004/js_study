'''

구성은

1. 문제 설명
2. 원본 문제(코드)
3. 강사 답안
4. 주최측 답안

순으로 되어있습니다.

빈칸채우기와 한 줄 수정의 경우 
강사 답안과 주최 답안이 유사 / 동일할 수 있습니다.


#문제4
자연수가 중복 없이 들어있는 리스트가 있습니다. 
이 리스트에서 합이 K의 배수가 되도록 서로 다른 숫자 세개를 고르는 방법은 몇 가지인지 세려고 합니다.

자연수가 들어있는 리스트 arr가 매개변수로 주어질 때, 
이 리스트에서 합이 K의 배수가 되도록 서로 다른 숫자 세개를 고르는 
방법의 가짓수를 return 하도록 solution 함수를 완성해주세요.

---
#####매개변수 설명
자연수가 들어있는 리스트 arr가 solution 함수의 매개변수로 주어집니다.
* arr의 길이는 3 이상 100 이하입니다.
* arr에는 1 이상 1,000 이하의 자연수가 중복 없이 들어있습니다.
* K는 1 이상 10 이하의 자연수입니다.

---
#####return 값 설명
리스트에서 합이 K의 배수가 되도록 서로 다른 숫자 세개를 고르는 방법의 가짓수를 return 해주세요.
* 그러한 방법이 없다면 0을 return 하면 됩니다.

---
#####예시

| arr             | K | return |
|-----------------|---|--------|
| [1, 2, 3, 4, 5] | 3 | 4      |

#####예시 설명

다음과 같이 4가지 방법이 있습니다.

* 1 + 2 + 3 = 6
* 1 + 3 + 5 = 9
* 2 + 3 + 4 = 9
* 3 + 4 + 5 = 12

#다음과 같이 import를 사용할 수 있습니다.
#import math

def solution(arr, K):
    #여기에 코드를 작성해주세요.
    answer = 0
    return answer

#아래는 테스트케이스 출력을 해보기 위한 코드입니다.
arr = [1, 2, 3, 4, 5]
K = 3
ret = solution(arr, K)

#[실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
print("solution 함수의 반환 값은 ", ret, " 입니다.")

'''

#다음과 같이 import를 사용할 수 있습니다.
#import math

def solution(arr, K):
    #여기에 코드를 작성해주세요.
    new_lister, tgt_len = [], len(arr)
    '''
    0번재 숫자부터 하나씩 뽑아 총 3개의 숫자를 선택합니다.
    숫자는 각각 i, j, k번째 인덱스로 뽑아냅니다.
    i <= j <= k 관계입니다.
    여기에서 3개의 숫자가 중복되면 안되므로(서로다른 숫자를 원하므로) 중복제거가 필요합니다.
    '''
    for i in range(tgt_len):
        init = arr[i]
        for j in range(i, tgt_len):
            midi = arr[j]
            for k in range(j, tgt_len):
                endy = arr[k]
                if len({init, midi, endy}) != 3: continue
                # 중복제거를 위해 세트(집합) 자료형을 이용합니다.
                # 세트로 만들었을 때 len으로 개수를 파악하여 3개가 아닌 경우 중복이 있다는 의미입니다.
                # 따라서 중복이 없는 경우만 신경쓰기 위해 continue 처리합니다.
                if (init + midi + endy) % 3 == 0:
                    # 숫자의 총 합이 3의 배수가 되는 경우를 원하므로 
                    # %3 == 0 불리언 조건을 이용합니다.
                    # 이 불리언 조건을 만족하는 경우 리스트에 해당 조합을 넣어줍니다.
                    new_lister.append([init, midi, endy])
    answer = len(new_lister)
    # 결과는 리스트가 아닌 조합이 몇 개 있는지만 물어보므로
    # len() 이용하여 리스트 안에 몇 개가 있는지 파악합니다.
    print(new_lister)
    return answer

#아래는 테스트케이스 출력을 해보기 위한 코드입니다.
arr = [1, 2, 3, 4, 5]
K = 3
ret = solution(arr, K)

#[실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
print("solution 함수의 반환 값은 ", ret, " 입니다.")


'''
주최 제공 답안
def solution(arr, K):
    n = len(arr)
    count = 0
    for p in range(0, n):
        for q in range(p + 1, n):
            for r in range(q + 1, n):
                if (arr[p] + arr[q] + arr[r]) % K == 0:
                    count += 1
    return count
'''