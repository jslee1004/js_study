'''

구성은

1. 문제 설명
2. 원본 문제(코드)
3. 강사 답안
4. 주최측 답안

순으로 되어있습니다.

빈칸채우기와 한 줄 수정의 경우 
강사 답안과 주최 답안이 유사 / 동일할 수 있습니다.


#문제8
1번부터 N번까지 후보에 대해서 투표를 진행했습니다. 
예를 들어 투표 결과가 [1, 5, 4, 3, 2, 5, 2, 5, 5, 4]라면 
순서대로 [1번, 5번, 4번, 3번, 2번, 5번, 2번, 5번, 5번, 4번] 후보에 투표했음을 나타냅니다. 
이때, 가장 많은 표를 받은 후보의 번호를 구하려고 합니다.

주어진 solution 함수는 후보의 수 N과 투표를 진행한 결과가 담긴 리스트 votes가 매개변수로 주어졌을 때, 
가장 많은 표를 받은 후보의 번호를 return 하는 함수입니다. 

그러나, 코드 일부분이 잘못되어있기 때문에, 몇몇 입력에 대해서는 올바르게 동작하지 않습니다. 
주어진 코드에서 _**한 줄**_만 변경해서 모든 입력에 대해 올바르게 동작하도록 수정하세요.

---
#####매개변수 설명
후보의 수 N과 투표 결과가 들어있는 리스트 votes가 solution 함수의 매개변수로 주어집니다.
* N은 1 이상 10 이하의 자연수입니다.
* votes의 길이는 1 이상 100 이하입니다.
* votes의 원소는 1 이상 N이하의 자연수입니다.

---
#####return 값 설명
가장 많은 표를 받은 후보의 번호를 리스트에 담아 return 해주세요
* 만약 가장 많은 표를 받은 후보가 2개 이상이라면, 그 후보들의 번호를 모두 리스트에 담아 오름차순 정렬하여 return 해주세요.

---
#####예시

| N | votes                 | return |
|---|-----------------------|--------|
| 5 | [1,5,4,3,2,5,2,5,5,4] | [5]    |
| 4 | [1,3,2,3,2]           | [2,3]  |

#####예시 설명
예시 #1
1번부터 5번까지 5개의 후보가 있으며, 투표 결과는 [1, 5, 4, 3, 2, 5, 2, 5, 5, 4]입니다. 
각 후보의 득표수는 다음과 같습니다.

* 1번 후보가 1표
* 2번 후보가 2표
* 3번 후보가 1표
* 4번 후보가 2표
* 5번 후보가 4표

이 경우 5번 후보가 4표로 가장 많은 표를 얻었습니다.

예시 #2
1번 후보가 1표, 2번 후보가 2표, 3번 후보가 2표씩 받았습니다. 
2번과 3번 후보가 공동으로 가장 많은 표를 받았기 때문에 [2, 3]을 오름차순 정렬하여 return 하면 됩니다.



def solution(N, votes):
    vote_counter = [0 for i in range(N+1)]
    for i in votes:
        vote_counter[i] += 1
    max_val = max(vote_counter)

    answer = []
    for idx in range(1, N + 1):
        if vote_counter[idx] == max_val:
            answer.append(vote_counter[idx])
    return answer


#The following is code to output testcase. The code below is correct and you shall correct solution function.
N1 = 5
votes1 = [1,5,4,3,2,5,2,5,5,4]
ret1 = solution(N1, votes1)

#Press Run button to receive output.
print("Solution: return value of the function is ", ret1, " .")


N2 = 4
votes2 = [1, 3, 2, 3, 2]
ret2 = solution(N2, votes2)

#Press Run button to receive output.
print("Solution: return value of the function is ", ret2, " .")

'''


def solution(N, votes):
    vote_counter = [0 for i in range(N+1)]
    # 0번 후보부터 N번 후보까지 index번호가 후보의 득표량입니다.
    # 처음 만들 때 초기화를 위해 0을 일괄 넣는 모습입니다.
    for i in votes:
        vote_counter[i] += 1
        # i번째 자리에 1씩 넣는 상황입니다.
        # i번째는 i번째 후보의 득표량이므로 votes 이름의 투표함에서
        # 꺼낸 숫자인 i가 i번째 후보의 득표수를 올려줍니다.
    max_val = max(vote_counter)
    # 가장 많은 득표수를 얻은 후보의 득표수를 max_val로 저장합니다.
    answer = []
    for idx in range(1, N + 1):
        # 0번째 후보부터 N번째 후보까지의 기호번호를 뽑는 용도의 for문입니다.
        if vote_counter[idx] == max_val:
            # 가장 많은 득표수를 얻은 후보인지 여부를 판별하기 위해
            # max_val에 저장된 수치와 동일한 값의 득표수를 갖는 후보를 선택합니다. 
            answer.append(idx)
            # idx가 후보의 번호이고 
            # vote_counter[idx]가 후보의 득표횟수이기 때문에
            # 후보의 득표횟수가 아닌 후보의 번호를 넣어줍니다.
            # for문을 break등으로 멈추지 않기 때문에 
            # 후보간 득표수가 동일한 경우에도 append 됩니다.
    return answer


#The following is code to output testcase. The code below is correct and you shall correct solution function.
N1 = 5
votes1 = [1,5,4,3,2,5,2,5,5,4]
ret1 = solution(N1, votes1)

#Press Run button to receive output.
print("Solution: return value of the function is ", ret1, " .")


N2 = 4
votes2 = [1, 3, 2, 3, 2]
ret2 = solution(N2, votes2)

#Press Run button to receive output.
print("Solution: return value of the function is ", ret2, " .")

'''
주최 제공답안
def solution(N, votes):
    vote_counter = [0 for i in range(N+1)]
    for i in votes:
        vote_counter[i]+=1
        
    max_val = max(vote_counter)

    answer = []
    for idx in range(1, N + 1):
        if vote_counter[idx] == max_val:
            answer.append(idx)
    return answer
'''