'''

구성은

1. 문제 설명
2. 원본 문제(코드)
3. 강사 답안
4. 주최측 답안

순으로 되어있습니다.

빈칸채우기와 한 줄 수정의 경우 
강사 답안과 주최 답안이 유사 / 동일할 수 있습니다.


#문제4
어느 누군가가 타임머신을 타고 과거로 가서 숫자 0이 없는 수 체계를 전파했습니다. 
역사가 바뀌어 이제 사람들의 의식 속엔 0이란 숫자가 사라졌습니다. 
따라서, 현재의 수 체계는 1, 2, 3, ..., 8, 9, 11, 12, ...와 같이 0이 없게 바뀌었습니다.

0을 포함하지 않은 자연수 num이 매개변수로 주어질 때, 
이 수에 1을 더한 수를 return 하도록 solution 함수를 완성해주세요.

---

#####매개변수 설명
자연수 num이 solution 함수의 매개변수로 주어집니다.
* num은 1 이상 999,999,999,999,999,999 이하의 0을 포함하지 않는 자연수입니다.

---

#####return 값 설명
자연수 num에 1을 더한 수를 return 해주세요.

---

#####예시

| num     | return |
|---------|---------|
| 9949999 | 9951111 |

#####예시 설명

9,949,999에 1을 더하면 9,950,000이지만 0은 존재하지 않으므로 9,951,111이 됩니다.


#You may use import as below.
#import math

def solution(num):
    # Write code here.
    answer = 0
    return answer


#The following is code to output testcase.
num = 9949999;
ret = solution(num)

#Press Run button to receive output. 
print("Solution: return value of the function is", ret, ".")

'''

#You may use import as below.
#import math

def solution(num):
    answer = num + 1
    # num+1 을 answer변수에 넣어 앞으로 활용합니다.
    # 결국 0만 없으므로 0이 나오는 모든 숫자를 건너뛰는 방향으로 코딩합니다.
    while True: # 몇 회 반복할지 알 수 없으므로 while True 사용합니다.
        if '0' in str(answer): answer = answer + 1
        # 만약 문자열 0이 answer를 문자열로 변환한 결과 안에 있다면 다음 숫자로 넘어갑니다.
        else: break
        # 문자열 0이 없다면 반복을 종료합니다.
    return answer


#The following is code to output testcase.
num = 9949999;
ret = solution(num)

#Press Run button to receive output. 
print("Solution: return value of the function is", ret, ".")

'''
주최 제공답안
# <undefined>
# import <undefined>

def solution(num):
    num += 1
    digit = 1
    while num // digit % 10 == 0:
        num += digit
        digit *= 10
    return num

'''
