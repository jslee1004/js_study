
'''

구성은

1. 문제 설명
2. 원본 문제(코드)
3. 강사 답안
4. 주최측 답안

순으로 되어있습니다.

빈칸채우기와 한 줄 수정의 경우 
강사 답안과 주최 답안이 유사 / 동일할 수 있습니다.


#문제6
체스에서 나이트(knight)는 아래 그림과 같이 동그라미로 표시된 8개의 방향중 한 곳으로 한 번에 이동이 가능합니다.

![image](https://s3.ap-northeast-2.amazonaws.com/grepp-cloudfront/programmers_imgs/challengeable-imgs/20180315_knight.png)

단, 나이트는 체스판 밖으로는 이동할 수 없습니다.

체스판의 각 칸의 위치는 다음과 같이 표기합니다.
![image](https://s3.ap-northeast-2.amazonaws.com/grepp-cloudfront/programmers_imgs/challengeable-imgs/20180315_knight2.png)
예를 들어, A번줄과 1번줄이 겹치는 부분은 'A1'이라고 합니다.

나이트의 위치 pos가 매개변수로 주어질 때, 나이트를 한 번 움직여서 이동할 수 있는 칸은 몇개인지 return 하도록 solution 함수를 완성해주세요.

---

#####매개변수 설명
나이트의 위치 pos가 solution 함수의 매개변수로 주어집니다.
* pos는 A부터 H까지의 대문자 알파벳 하나와 1 이상 8이하의 정수 하나로 이루어진 두 글자 문자열입니다.
* 잘못된 위치가 주어지는 경우는 없습니다.

---

#####return 값 설명
나이트를 한 번 움직여서 이동할 수 있는 칸의 개수를 return 해주세요.

---
#####예시

| pos  | return |
|------|--------|
| "A7" | 3      |

#####예시 설명
나이트가 A7 위치에 있으면 아래 그림과 같이 왼쪽으로는 이동하지 못하고, 오른쪽으로는 맨 위를 제외한 나머지 세 칸으로 이동 가능합니다. 
![image](https://s3.ap-northeast-2.amazonaws.com/grepp-cloudfront/programmers_imgs/challengeable-imgs/20180315_knight3.png)
따라서, 3을 return 하면 됩니다.


#You may use import as below.
#import math

def solution(pos):
    # Write code here.
    answer = 0
    return answer

#The following is code to output testcase.
pos = "A7"
ret = solution(pos)

#Press Run button to receive output.
print("Solution: return value of the function is", ret, ".")

'''

#You may use import as below.
#import math

def solution(pos):
    answer = 0
    x_bound, y_bound = 'ABCDEFGH', '12345678'
    # x좌표와 y좌표의 유효범위를 판별하기 위한 문자열입니다.
    base_x, base_y = x_bound.index(pos[0]), y_bound.index(pos[1])
    # 나이트의 좌표가 x와 y기준으로 몇 번째인지를 각각 base_x와 base_y변수에 넣어줍니다.
    long_x, long_y = [base_x - 2, base_x + 2], [base_y - 2, base_y + 2]
    short_x, short_y = [base_x - 1, base_x + 1], [base_y - 1, base_y + 1]
    # x와 y좌표가 변하는 경우의 수는 각각 +-1, +-2로 4가지씩 입니다.(안 움직이는 경우 없음)
    # long_x, long_y에는 2만큼 떨어지는 위치를 할당합니다.
    # short_x, short_y에는 1만큼 떨어지는 위치를 할당합니다.
    # 여기에서의 위치는 x_bound, y_bound 문자열 상의 인덱스 번호입니다.
    for x_points, y_points in [[long_x, short_y], [long_y, short_x]]:
        # x와 y좌표의 경우의 수로부터 나이트가 움직일 수 있는 경우를 알아보면
        # 둘 중에 하나는 2칸, 그리고 나머지 하나는 1칸 움직입니다.
        # 따라서 long_x와 short_y를 묶고 short_x와 long_y를 묶어 조합합니다.
        for x_point in x_points:
            # x_points 안에는 두 개의 x좌표(x_point)가 있습니다.
            if x_point < 0 or x_point > 7: continue
                # x좌표인 x_point가 x_bound 문자열 상의 인덱스 범위인 0 ~ 7을 벗어나면
                # 나이트가 움직일 수 없는 x좌표이므로 다음 조합으로 넘어갑니다.
            for y_point in y_points:
                # y_points 안에는 두 개의 y좌표가 있습니다.
                if y_point < 0 or y_point > 7: continue
                # y좌표인 y_point가 y_bound 문자열 상의 인덱스 범위인 0 ~ 7을 벗어나면
                # 나이트가 움직일 수 없는 y좌표이므로 다음 조합으로 넘어갑니다.
                answer = answer + 1
                # x좌표와 y좌표가 전부 인덱스 범위 0 ~ 7 (A ~ H, 1 ~ 8)이므로 
                # 유효한 조합이라 판단하여 answer 변수에 1을 더해줍니다.
    return answer

#The following is code to output testcase.
pos = "A7"
ret = solution(pos)

#Press Run button to receive output.
print("Solution: return value of the function is", ret, ".")


'''
주최 제공답안
def solution(pos):
    dx = [1,1,-1,-1,2,2,-2,-2]
    dy = [2,-2,-2,2,1,-1,-1,1]
    cx = ord(pos[0]) - ord("A")
    cy = ord(pos[1]) - ord("0") - 1
    ans = 0
    for i in range(8):
        nx = cx + dx[i]
        ny = cy + dy[i]
        if nx >= 0 and nx < 8 and ny >= 0 and ny < 8:
            ans += 1
    return ans
'''