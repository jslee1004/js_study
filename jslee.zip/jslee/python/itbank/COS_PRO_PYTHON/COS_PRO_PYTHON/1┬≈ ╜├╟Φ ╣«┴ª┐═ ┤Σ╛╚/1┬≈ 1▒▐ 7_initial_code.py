'''

구성은

1. 문제 설명
2. 원본 문제(코드)
3. 강사 답안
4. 주최측 답안

순으로 되어있습니다.

빈칸채우기와 한 줄 수정의 경우 
강사 답안과 주최 답안이 유사 / 동일할 수 있습니다.


#문제7
오름차순으로 정렬되어있는 두 리스트 arrA, arrB를 하나의 리스트로 합치려 합니다. 단, 합친 후의 리스트도 오름차순으로 정렬되어 있어야 합니다.

예를 들어 arrA = [-2, 3, 5, 9], arrB = [0, 1, 5]인 경우 두 리스트을 오름차순으로 정렬된 하나의 리스트로 합치면 [-2, 0, 1, 3, 5, 5, 9]가 됩니다.

오름차순으로 정렬된 두 리스트 arrA와 arrB가 주어졌을 때, 
두 리스트를 오름차순으로 정렬된 하나의 리스트로 합쳐서 return 하도록 solution 함수를 작성하려 합니다. 
빈칸을 채워 전체 코드를 완성해주세요.

---
##### 매개변수 설명
오름차순으로 정렬된 두 리스트 arrA와 arrB가 solution 함수의 매개변수로 주어집니다.

* arrA의 길이는 1 이상 200,000 이하입니다.
* arrA의 원소는 -1,000,000 이상 1,000,000 이하의 정수입니다.
* arrB의 길이는 1 이상 200,000 이하입니다.
* arrB의 원소는 -1,000,000 이상 1,000,000 이하의 정수입니다.

---
##### return 값 설명
두 리스트 arrA, arrB를 오름차순으로 정렬된 하나의 리스트로 합쳐서 return 해주세요.

---
##### 예시

| arrA          | arrB      | return                 |
|---------------|-----------|------------------------|
| [-2, 3, 5, 9] | [0, 1, 5] | [-2, 0, 1, 3, 5, 5, 9] |



def solution(arrA, arrB):
    arrA_idx = 0
    arrB_idx = 0
    arrA_len = len(arrA)
    arrB_len = len(arrB)
    answer = []
    while @@@:
        if arrA[arrA_idx] < arrB[arrB_idx]:
            answer.append(arrA[arrA_idx])
            arrA_idx += 1
        else:
            answer.append(arrB[arrB_idx])
            arrB_idx += 1
    while @@@:
        answer.append(arrA[arrA_idx])
        arrA_idx += 1
    while @@@:
        answer.append(arrB[arrB_idx])
        arrB_idx += 1
    return answer


#The following is code to output testcase.
arrA = [-2, 3, 5, 9]
arrB = [0, 1, 5]
ret = solution(arrA, arrB);

#Press Run button to receive output.
print("Solution: return value of the function is ", ret, " .")

'''


def solution(arrA, arrB):
    '''
    서로 다른 리스트 2개로 하나의 리스트를 만드는 문제입니다.
    먼저 만들어진 변수를 보니 인덱스(순서)와 len(길이)를
    이용함을 알 수 있습니다.
    '''
    arrA_idx = 0
    arrB_idx = 0
    arrA_len = len(arrA)
    arrB_len = len(arrB)
    answer = []
    '''
    가완성된 코드를 보니 while문이 3개 있습니다. 

    첫 while문에서는 if ~ else 경우의 수로 
    answer 변수에 arrA와 arrB 모두로부터
    하나씩 꺼내서 집어넣게 됩니다.
    
    두 번째와 세 번째 while문에서는
    각각 arrA, arrB에서 따로따로 뽑아서 넣습니다.
    '''
    while arrA_idx < arrA_len and arrB_idx < arrB_len:
        # arrA와 arrB의 갯수의 교집합 부분입니다.
        # 둘 중 더 적은 리스트를 기준으로 해당 리스트의 개수만큼 반복합니다.
        # 반복시 arrA와 arrB의 제일 앞에것끼리 비교하여 더 작은 것을 선택해 answer 리스트에 집어넣고
        # arrA와 arrB중 작은것을 선택한 것은 다음 번째 인덱스로 넘어가기 의해 += 1을 사용합니다.
        if arrA[arrA_idx] < arrB[arrB_idx]:
            answer.append(arrA[arrA_idx])
            arrA_idx += 1
        else:
            answer.append(arrB[arrB_idx])
            arrB_idx += 1
    while arrA_idx < arrA_len:
        # 만약 arrA가 arrB보다 개수가 많은 경우에는
        # 위 첫 번째 while이 끝난 이후  arrA에 숫자가 남아있을 것입니다.
        # 이를 전부 answer변수에 넣어주기 위한 부분입니다.
        answer.append(arrA[arrA_idx])
        arrA_idx += 1
    while arrB_idx < arrB_len:
        # 만약 arrB가 arrA보다 개수가 많은 경우에는
        # 위 첫 번째 while이 끝난 이후  arrB에 숫자가 남아있을 것입니다.
        # 이를 전부 answer변수에 넣어주기 위한 부분입니다.
        answer.append(arrB[arrB_idx])
        arrB_idx += 1
    return answer


#The following is code to output testcase.
arrA = [-2, 3, 5, 9]
arrB = [0, 1, 5]
ret = solution(arrA, arrB);

#Press Run button to receive output.
print("Solution: return value of the function is ", ret, " .")

'''
주최 제공답안
def solution(arrA, arrB):
    arrA_idx = 0
    arrB_idx = 0
    arrA_len = len(arrA)
    arrB_len = len(arrB)
    answer = []
    while arrA_idx < arrA_len and arrB_idx < arrB_len:
        if arrA[arrA_idx] < arrB[arrB_idx]:
            answer.append(arrA[arrA_idx])
            arrA_idx += 1
        else:
            answer.append(arrB[arrB_idx])
            arrB_idx += 1
            
    while arrA_idx < arrA_len:
        answer.append(arrA[arrA_idx])
        arrA_idx += 1
    while arrB_idx < arrB_len:
        answer.append(arrB[arrB_idx])
        arrB_idx += 1
        
    return answer
'''