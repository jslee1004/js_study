#!/usr/bin/env python
# coding: utf-8

# In[3]:


for i in range(12):
    i = i + 1
    print("*" * i)


# In[10]:



for i in range(12):
    star = "*"
    blank = " " * i
    print(blank + star)


# In[16]:


for i in range(12):
    j = 12 - i
    star = "*"
    blank = " " * j
    print(blank + star)


# In[17]:


n = 10
for i in range(n):
    j = n - 1 - i
    print(n , i, j)


# In[25]:


n = 9
for i in range(n):
    j = n - 1 - i
    if (n / 2) > i:
        print((" " * i) + "*" )
    else:
        print((" " * j) + "*" )


# In[32]:


n = 9
if n % 2 != 0:
    for i in range(n):
        j = n - 1 - i
        if (n / 2) > i:
            print((" " * i) + "*" )
        else:
            print((" " * j) + "*" )
else:
    print('짝수입니다! 다음 기회에...')


# In[66]:


n = 9
if n % 2 != 0:
    for i in range(n):
        j = n - 1 - i
        if (n / 2) > i:
            blank_l = " " * j
            blank_r = " " * ((2*i) - 1)
            star = '*'
            if i != 0:
                print(blank_l + star + blank_r + star)
            else:
                print(blank_l + star)
        else:
            blank_l = " " * i
            blank_r = " " * ((2*j) - 1)
            star = '*'
            if j != 0:
                print(blank_l + star + blank_r + star)
            else:
                print(blank_l + star + blank_r)
else:
    print('짝수입니다! 다음 기회에...')


# In[59]:


n = 9
if n % 2 != 0:
    for i in range(n):
        j = n - 1 - i
        if (n / 2) > i:
            print(("*" * i) + "*" )
        else:
            print(("*" * j) + "*" )
else:
    print('짝수입니다! 다음 기회에...')


# In[67]:


n = 9
if n % 2 != 0:
    for i in range(n):
        j = n - 1 - i
        if (n / 2) > i:
            blank_l = " " * j
            blank_r = "*" * ((2*i) - 1)
            star = '*'
            if i != 0:
                print(blank_l + star + blank_r + star)
            else:
                print(blank_l + star)
        else:
            blank_l = " " * i
            blank_r = "*" * ((2*j) - 1)
            star = '*'
            if j != 0:
                print(blank_l + star + blank_r + star)
            else:
                print(blank_l + star + blank_r)
else:
    print('짝수입니다! 다음 기회에...')


# In[69]:


n = 9
for i in range(n):
    j = n - 1 - i
    if (n / 2) > i:
         print(("*" * i))
    else:
        print(("*" * j))


# In[78]:


n = 9
for i in range(n):
    j = n -i -1
    if n / 2 > i:
        blank = " " * j
        star = '*' * i
    else:
        blank = " " * i
        star = '*' * j
    print(blank + star)


# In[87]:


def factorial(n):
    result = 1
    for i in range(n):
        result = result * (i + 1)
    return result
factorial(4)


# # 리스트

# In[90]:


odd = [1, 3, 5, 7, 9]
odd2 = odd + odd
print(odd2)


# In[91]:


odd3 = odd *3
print(odd3)


# In[92]:


odd3 = odd *3.5
print(odd3)


# In[96]:


odd[:4]


# In[97]:


odd[:]


# In[98]:


odd[::]


# ##### [시작 : 끝 : 간격(step)]

# In[99]:


odd[::2]


# In[100]:


odd[1::2]


# In[101]:


odd[::-1]


# # 튜플(tuple)

# In[103]:


odd = (1, 3, 5, 7, 9)


# In[104]:


odd2 = odd *2
print (odd2)


# In[105]:


odd2 = odd * 2.5


# In[106]:


print(odd[0])
print(odd[1])
print(odd[-1])
print(odd[-2])


# In[107]:


print(odd[1:4])


# In[109]:


print(odd[::2])


# In[110]:


print(odd[1::2])


# # 딕셔너리

# In[120]:


address = {'key':'value',"phone": "010-1234-5678"}
print(address['key'])


# In[121]:


address['value'] = 180
print(address)


# In[129]:


address['value'] = 150
print(address)


# In[130]:


del address['value']
del address['010-1234-5678']
print(address)


# ##### Create
# ##### Read
# ##### Update
# ##### Delete

# In[ ]:




