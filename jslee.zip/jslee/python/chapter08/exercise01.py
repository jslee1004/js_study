def division(n1, n2):
	if n2 == 0:
		print('0으로 나눌 수 없습니다.')
		
		return
	else:
		print('나눗셈 연산 결과 : ')
		print(int(n1) / int(n2))
		return
    
print('나눗셈 연산을 합니다.')
userInt01 = int(input('첫 번째 정수를 입력하세요.'))
userInt02 = int(input('두 번째 정수를 입력하세요.'))

division(userInt01, userInt02)