print('덧셈 연산을 합니다.')
print(-2 + 5)

print('덧셈 연산을 합니다.')
print(3 + 10)

print('덧셈 연산을 합니다.')
print(-3 + 0)

print('덧셈 연산을 합니다.')
print(-5 + 5)

print('덧셈 연산을 합니다.')
print(30 + 7)

def addFuntion(n1, n2):
	print('덧셈 연산을 합니다.')
	sum = n1 + n2
	
	return sum

print(addFuntion(-2, 5))
print(addFuntion(3, 10))
print(addFuntion(-3, 0))
print(addFuntion(-5, 5))
print(addFuntion(30, 7))
