str = 'good morning'

def printHello(name):
	print(name, end = "")
	print(', ', end = "")
	str = 'good afternoon.'
	print(str)
	
	return

printHello('Teacher')

print(str)