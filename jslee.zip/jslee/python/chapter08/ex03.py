def addCalculator(num1, num2):
	sum = num1 + sum2
	return sum
	

def printStr(str):
    print(str)
    return

printStr('함수! 어렵지 않아요')
printStr('함수! 재미있어요')

def printGugudan(num):
	print(num, end = "")
	print("단")
		
	for i in range(1, 10):
		print(num, end = "")
		print(" * ", end = "")
		print(i, end = "")
		print(" = ", end = "")
		print(num * i)
	
	return

printGugudan(2)
printGugudan(4)

# 매개변수가 필요 없는 경우
def playHello():
	print('어서 오세요')
	
	return
	
playHello()

# 2개 이상의 매개변수
def printText(str, num):
	for i in range(num):
		print(str)
		
	return
	
printText('Hello~', 3)

# 데이터 반환이 있는 경우
def returnFun1(n1, n2):
	sum = n1 + n2
	
	return sum

result = returnFun1(3, 5)
print(result)

# 데이터 반환이 없는 경우
def returnFun2(n1, n2):
	sum = n1 + n2
	print(sum)
	
	return

returnFun2(3, 5)


