str = input('문자(열)을 입력하세요 : ')
strLen = len(str)
print('사용자가 입력한 문자열의 길이 : {0}'.format(strLen))

file = open('C:/python/pjt/chapter12/test.txt', 'w')
result = file.write(str)

print('\ntype of result : {0}'.format(type(result)))
print('result : {0}'.format(result))
file.close()

if strLen == result:
	print('\n문자(열)이 정상적으로 기록됐습니다.')
else:
	print('\n문자(열)이 정상적으로 기록되지 못했습니다.')