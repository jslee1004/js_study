'''list = ['hello python\n', 'hello c++\n', 'hello java\n']
for item in list:
	with open('C:/python/pjt/chapter12/writeLines.txt', 'a') as f:
		f.write(item)'''



list = ['hello python\n', 'hello c++\n', 'hello java\n']
with open('C:/python/pjt/chapter12/writeLines.txt', 'a') as f:
		f.writelines(list)
