file = open('C:/python/pjt/chapter12/test.txt', 'w')

file.close()