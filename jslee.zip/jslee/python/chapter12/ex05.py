file = open('C:/python/pjt/chapter12/number.txt', 'r')
result = file.read()
print('result : {0}'.format(result))
sum = int(result) + 1
print('sum : {0}'.format(sum))
file.close()