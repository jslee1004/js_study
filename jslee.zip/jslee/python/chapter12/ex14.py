with open('C:/python/pjt/chapter12/readLine.txt', 'r') as f:
	
	line = f.readline()
	while line != '':
			print('line : {0}'.format(line))
			line = f.readline()