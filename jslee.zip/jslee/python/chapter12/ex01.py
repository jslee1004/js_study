import time
import datetime

def getTime():
	ts = time.time()
	st = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
	return st

print('아래의 항목을 선택하세요.')
print('1.입금 \t 2.출금')
selectItem = int(input())

if selectItem == 1:
		print('입금액을 입력하세요.')
		money = int(input())
		
		with open('C:/python/pjt/chapter12/money.txt', 'r') as f:
				m = f.read()
		
		with open('C:/python/pjt/chapter12/money.txt', 'w') as f:
				f.write(str(int(m) + money))
		
		print('입금 내역을 입력하세요.')
		memo = input()
		
		with open('C:/python/pjt/chapter12/pocketMoneyRegister.txt', 'a') as f:
				f.write('-------------------------------------------\n')
				f.write(getTime() + '\n')
				f.write('[입금]' + memo + ' : ' + str(money) + '원' + '\n')
				f.write('[잔액]' + str(int(m) + money) + '원' + '\n')
		
		print('기존 잔액 : {0}'.format(m))
		print('입금후 잔액 : {0}'.format(int(m) + money))		
		print('입금이 완료되었습니다.')

elif selectItem == 2:
		print('출금액을 입력하세요.')
		money = int(input())
		
		with open('C:/python/pjt/chapter12/money.txt', 'r') as f:
				m = f.read()
		
		with open('C:/python/pjt/chapter12/money.txt', 'w') as f:
				f.write(str(int(m) - money))
				
		print('출금 내역을 입력하세요.')
		memo = input()
		
		with open('C:/python/pjt/chapter12/pocketMoneyRegister.txt', 'a') as f:
				f.write('-------------------------------------------\n')
				f.write(getTime() + '\n')
				f.write('[출금]' + memo + ' : ' + '-' + str(money) + '원' + '\n')
				f.write('[잔액]' + str(int(m) - money) + '원' + '\n')
		
		
		print('기존 잔액 : {0}'.format(m))
		print('출금후 잔액 : {0}'.format(int(m) - money))		
		print('출금이 완료되었습니다.')
		
else:
		print('잘못 입력하셨습니다.')