'''
file = open('C:/python/pjt/chapter12/withAs.txt', 'a')
file.write('Hello World!!')
file.close()
'''

with open('C:/python/pjt/chapter12/withAs.txt', 'a') as file:
	file.write('Hello World!!')


