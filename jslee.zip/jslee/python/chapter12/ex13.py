with open('C:/python/pjt/chapter12/readLines.txt', 'r') as f:
	tempList = f.readlines()
	print('type of f.readlines() : {0}'.format(type(tempList)))
	print('f.readlines() : {0}'.format(tempList))