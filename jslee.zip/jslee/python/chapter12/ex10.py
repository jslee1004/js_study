file = open('C:/python/pjt/chapter12/fileModeR.txt', 'r')
str = file.read()
print(str)
file.close()