file = open('fileNameTest.txt', 'w')
file.write('Hello World!!')
file.close()





