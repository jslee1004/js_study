file = open('C:/python/pjt/chapter12/fileModeA.txt', 'a')
file.write('\nHello python~~')
file.close()





