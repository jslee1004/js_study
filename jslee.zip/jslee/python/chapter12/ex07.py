file = open('C:/python/pjt/chapter12/fileModeW.txt', 'w')
file.write('Hello python~~')
file.close()





