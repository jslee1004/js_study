class ParentCls1:
		def __init__(self):
				print('-- ParentCls1 init() start --\n')
		
		def doParentMethod(self):
				print('-- ParentCls1 doParentMethod() start --\n')

class ParentCls2:
		def __init__(self):
				print('-- ParentCls2 init() start --\n')
		
		def doParentMethod(self):
				print('-- ParentCls2 doParentMethod() start --\n')

class ChildCls(ParentCls1, ParentCls2):
		def __init__(self):
				print('-- ChildCls init() start --\n')

myChildCls = ChildCls()
myChildCls.doParentMethod()