class TempCls:

        def __init__(self, n):
                print('-- init() start --\n')
                self.num = n
                
        def doMethod(self):
                pass

firstIns = TempCls(10)
secondIns = TempCls(10)
thirdIns = secondIns

if firstIns == secondIns:
	print('firstIns == secondIns')
else:
	print('firstIns != secondIns')

print('firstIns.num : {0}'.format(firstIns.num))
print('secondIns.num : {0}'.format(secondIns.num))

firstIns.num = 20

print('firstIns.num : {0}'.format(firstIns.num))
print('secondIns.num : {0}'.format(secondIns.num))

if secondIns == thirdIns:
	print('secondIns == thirdIns')
else:
	print('secondIns != thirdIns')

print('secondIns.num : {0}'.format(secondIns.num))
print('thirdIns.num : {0}'.format(thirdIns.num))

secondIns.num = 20

print('secondIns.num : {0}'.format(secondIns.num))
print('thirdIns.num : {0}'.format(thirdIns.num))

firstIns = secondIns
firstIns.num = 100
print('firstIns.num : {0}'.format(firstIns.num))
print('secondIns.num : {0}'.format(secondIns.num))
print('thirdIns.num : {0}'.format(thirdIns.num))

