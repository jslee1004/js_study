from abc import ABCMeta
from abc import abstractmethod

class ParentRestaurant(metaclass = ABCMeta):
		def __init__(self):
				print('-- ParentRestaurant init() start --\n')
		
		def makeJjajang(self):
				print('-- ParentRestaurant makeJjajang() start --')
		
		def makeJjamppong(self):
				print('-- ParentRestaurant makeJjamppong() start --')
		
		@abstractmethod
		def makeTangsuyuk(self):
				pass

class ChildRestaurant(ParentRestaurant):
		def __init__(self):
				print('-- ChildRestaurant init() start --\n')	

		def makeJjajang(self):
				print('-- ChildRestaurant makeJjajang() start --')
		
		def makeJjamppong(self):
				print('-- ChildRestaurant makeJjamppong() start --')				

		def makeBokeumbap(self):
				print('-- ChildRestaurant makeBokeumbap() start --')
		
		def makeTangsuyuk(self):
				print('-- ChildRestaurant makeTangsuyuk() start --')

childRestaurant = ChildRestaurant()

childRestaurant.makeJjajang()
childRestaurant.makeJjamppong()
childRestaurant.makeBokeumbap()
childRestaurant.makeTangsuyuk()