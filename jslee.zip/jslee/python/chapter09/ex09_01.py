class ParentRestaurant:
		def __init__(self):
				print('-- ParentRestaurant init() start --\n')
		
		def makeJjajang(self):
				print('-- ParentRestaurant makeJjajang() start --')
		
		def makeJjamppong(self):
				print('-- ParentRestaurant makeJjamppong() start --')

class ChildRestaurant(ParentRestaurant):
		def __init__(self):
				super().__init__()
				print('-- ChildRestaurant init() start --\n')

		def makeJjajang(self):
				print('-- ChildRestaurant makeJjajang() start --')
		
		def makeJjamppong(self):
				print('-- ChildRestaurant makeJjamppong() start --')			


		def makeBokeumbap(self):
				print('-- ChildRestaurant makeBokeumbap() start --')

childRestaurant = ChildRestaurant()

childRestaurant.makeJjajang()
childRestaurant.makeJjamppong()
childRestaurant.makeBokeumbap()