class ParentCls:
		def __init__(self, n):
				print('-- ParentCls init() start --\n')
				self.num = n
		
		def doParentMethod(self):
				print('-- doParentMethod() start --\n')

class ChildCls(ParentCls):
		def __init__(self):
				print('-- ChildCls init() start --\n')

myChildCls = ChildCls()
myChildCls.doParentMethod()