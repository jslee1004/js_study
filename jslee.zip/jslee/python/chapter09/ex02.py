class Grandeur:

        def __init__(self, color, size, displacement):
                print('\n-- init() start --\n')
                self.color = color;
                self.size = size
                self.displacement = displacement;

        # 주행
        def doDrive(self):
                print('-- doDrive() start --')
                return

        # 정지
        def doStop(self):
                print('-- doStop() start --')
                return
        
        # 주차
        def doParking(self):
                print('-- doParking() start --')
                return

        # 터보
        def doTurbo(self):
                print('-- doTurbo() start --')
                return

        # 차정보
        def getInfo(self):
                print('Color:{0}'.format(self.color))
                print('Size: {0} cm'.format(self.size))
                print('Displacement: {0} cc'.format(self.displacement))
                return


myGrandeur = Grandeur('Black', 200, 2000)
myGrandeur.doDrive()
myGrandeur.doStop()
myGrandeur.doParking()
myGrandeur.doTurbo()
myGrandeur.getInfo()

friendGrandeur = Grandeur('Red', 200, 2200)
friendGrandeur.doDrive()
friendGrandeur.doStop()
friendGrandeur.doParking()
friendGrandeur.doTurbo()
friendGrandeur.getInfo()

brotherGrandeur = Grandeur('Blue', 200, 3000)
brotherGrandeur.doDrive()
brotherGrandeur.doStop()
brotherGrandeur.doParking()
brotherGrandeur.doTurbo()
brotherGrandeur.getInfo()

friendGrandeur.color = 'Orange'
friendGrandeur.size = 300
friendGrandeur.displacement = 5000

friendGrandeur.getInfo()