class ParentCls:
		def __init__(self, n):
				print('-- ParentCls init() start --\n')
				self.num = n
		
		def doParentMethod(self, n):
				print('-- doParentMethod() start --')
				print('n : {0}\n'.format(n))

class ChildCls(ParentCls):
		def __init__(self):
				#ParentCls.__init__(self, 10)
				super().__init__(10)
				print('-- ChildCls init() start --\n')
				super().doParentMethod(1)

myChildCls = ChildCls()
myChildCls.doParentMethod(2)

print('myChildCls.num : {0}'.format(myChildCls.num))