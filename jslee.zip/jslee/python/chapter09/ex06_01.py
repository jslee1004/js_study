class ParentCls:
		def __init__(self, n):
				print('-- ParentCls init() start --\n')
				self.num = n
		
		def doParentMethod(self):
				print('-- doParentMethod() start --\n')

class ChildCls(ParentCls):
		def __init__(self):
				ParentCls.__init__(self, 10)
				print('-- ChildCls init() start --\n')

myChildCls = ChildCls()
myChildCls.doParentMethod()

print('myChildCls.num : {0}'.format(myChildCls.num))