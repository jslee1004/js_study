class Calculator:

        def __init__(self, n1, oper, n2):
                print('-- init() start --\n')
                self.n1 = n1
                self.oper = oper
                self.n2 = n2

        # 연산 실행
        def doOperation(self):
                if self.oper == '+':
                        self.addition()
                elif self.oper == '-':
                        self.subtraction()
                elif self.oper == '*':
                        self.multiplication()
                elif self.oper == '/':
                        self.division()
                elif self.oper == '//':
                        self.portion()
                return

        # 덧셈 연산 메서드
        def addition(self):
                print('-- addition() start --')
                result = int(self.n1) + int(self.n2)
                print('덧셈 연산 결과 : {0}\n'.format(result))
                return
        
        # 뺄셈 연산 메서드
        def subtraction(self):
                print('-- subtraction() start --')
                result = int(self.n1) - int(self.n2)
                print('뺄셈 연산 결과 : {0}\n'.format(result))
                return

        # 곱셈 연산 메서드
        def multiplication(self):
                print('-- multiplication() start --')
                result = int(self.n1) * int(self.n2)
                print('곱셈 연산 결과 : {0}\n'.format(result))
                return

        # 나눗셈 연산 메서드
        def division(self):
                print('-- division() start --')
                result = int(self.n1) / int(self.n2)
                print('나눗셈 연산 결과 : {0}\n'.format(result))
                return

        # 몫 연산 메서드
        def portion(self):
                ('-- portion() start --')
                result = int(self.n1) // int(self.n2)
                print('몫 연산 결과 : {0}\n'.format(result))
                return


firstNum = input()
operator = input()
secondNum = input()

myCalculator = Calculator(firstNum, operator, secondNum)
myCalculator.doOperation()