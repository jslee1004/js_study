class Addition:
		def __init__(self):
				print('-- Addition init() start --')
		
		def doCalculation(self, n1, n2):
				return n1 + n2

class Subtraction:
		def __init__(self):
				print('-- Subtraction init() start --')
		
		def doCalculation(self, n1, n2):
				return n1 - n2

class Multiplication:
		def __init__(self):
				print('-- Multiplication init() start --')
		
		def doCalculation(self, n1, n2):
				return n1 * n2

class Division:
		def __init__(self):
				print('-- Division init() start --')
		
		def doCalculation(self, n1, n2):
				return n1 / n2

class Portion:
		def __init__(self):
				print('-- Portion init() start --')
		
		def doCalculation(self, n1, n2):
				return n1 // n2

class Calculator:
		def __init__(self, oper):
				print('-- Calculator init() start --\n')
				self.oper = oper
		
		def doOperation(self, n1, n2):
			if self.oper == '+':
					print(Addition().doCalculation(n1, n2))
			elif self.oper == '-':
					print(Subtraction().doCalculation(n1, n2))
			elif self.oper == '*':
					print(Multiplication().doCalculation(n1, n2))
			elif self.oper == '/':
					print(Division().doCalculation(n1, n2))
			elif self.oper == '//':
					print(Portion().doCalculation(n1, n2))
		
firstNum = int(input('첫 번째 숫자를 입력하세요.  :  '))
operator = input('연산자를 입력하세요.  :   ')
secondNum = int(input('두 번째 숫자를 입력하세요.  :  '))

myCalculator = Calculator(operator)
myCalculator.doOperation(firstNum, secondNum)