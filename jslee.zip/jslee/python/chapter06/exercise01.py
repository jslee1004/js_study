import random

# 무작위 난수 생성(1 or 2)
ranNum = random.sample(range(1, 3), 1)

# 난수 comNum 변수에 저장
comNum = ranNum[0]

print('홀수일까요? 짝수일까요? 1.홀, 2.짝')

user01Num = int(input('첫 번째 사용자 입력 : '))
user02Num = int(input('두 번째 사용자 입력 : '))

if (user01Num % 2) == (comNum % 2):
	print('첫 번째 사용자 맞췄습니다.')
else:
	print('첫 번째 사용자 틀렸습니다.')

if (user02Num % 2) == (comNum % 2):
	print('두 번째 사용자 맞췄습니다.')
else:
	print('두 번째 사용자 틀렸습니다.')

print('컴퓨터 숫자: ')
print(comNum)