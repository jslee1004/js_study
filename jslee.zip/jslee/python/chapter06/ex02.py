myScore = 75
targetScore = 80

# if문
if myScore >= targetScore:
	print('잘했어요~')
	
# if ~ else문
if myScore >= targetScore:
	print('잘했어요~')
else:
	print('좀 더 노력하세요~')
	
# if ~ elif문
if myScore >= 90:
	print('수')
elif myScore >= 80:
	print('우')
elif myScore >= 70:
	print('미')
elif myScore >= 60:
	print('양')
else:
	print('가')