# 숫자 비교
firstbool = True
secondbool = False

# not
print(not firstbool)

# and
print(firstbool and secondbool)
print(firstbool and not secondbool)

# or
print(firstbool or secondbool)
print(not firstbool or secondbool)