firstNum = input()
operator = input()
secondNum = input()

if operator == '+':
	# 덧셈 연산
	print('덧셈 연산 결과 : ')
	print(int(firstNum) + int(secondNum))
elif operator == '-':
	# 뺄셈 연산
	print('뺄셈 연산 결과 : ')
	print(int(firstNum) - int(secondNum))
elif operator == '*':
	# 곱셈 연산
	print('곱셈 연산 결과 : ')
	print(int(firstNum) * int(secondNum))
elif operator == '/':
	# 나눗셈 연산
	print('나눗셈 연산 결과 : ')
	print(int(firstNum) / int(secondNum))
elif operator == '%':
	# 나머지 연산
	print('나머지 연산 결과 : ')
	print(int(firstNum) % int(secondNum))
elif operator == '//':
	# 몫 연산
	print('몫 연산 결과 : ')
	print(int(firstNum) // int(secondNum))
