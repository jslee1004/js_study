# 숫자 비교
firstNum = 10
secondNum = 3

# ==
print(firstNum == secondNum)

# !=
print(firstNum != secondNum)

# >
print(firstNum > secondNum)

# >=
print(firstNum >= secondNum)

# <
print(firstNum < secondNum)

# <=
print(firstNum <= secondNum)

# 문자열 비교
firstStr = 'Hello'
secondStr = 'python'

# ==
print(firstStr == secondStr)

# !=
print(firstStr != secondStr)

# 문자 비교
firstChar = 'a'
secondChar = 'z'

# ==
print(firstChar == secondChar)

# !=
print(firstChar != secondChar)

# >
print(firstChar > secondChar)

# >=
print(firstChar >= secondChar)

# <
print(firstChar < secondChar)

# <=
print(firstChar <= secondChar)

