std01 = int(input('학생01 점수 : '))
std02 = int(input('학생02 점수 : '))
std03 = int(input('학생03 점수 : '))
std04 = int(input('학생04 점수 : '))
std05 = int(input('학생05 점수 : '))


total = std01 + std02 + std03 + std04 + std05
average = total / 5

print('Total : {0}'.format(total))
print('Average : {0}'.format(average))

if average >= 80:
	print('Pass')
else:
	print('Try again')