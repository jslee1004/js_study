firstNum = 10
secondNum = 3

firstStr = 'Hello'
secondStr = ' '
thirdStr = 'python'

# 덧셈 연산
print(firstNum + secondNum)
print(firstStr + secondStr + thirdStr)

# 뺄셈 연산
print(firstNum - secondNum)

# 곱셈 연산
print(firstNum * secondNum)

# 나눗셈 연산
print(firstNum / secondNum)

# 나머지 연산
print(firstNum % secondNum)

# 몫 연산
print(firstNum // secondNum)
