from abc import ABCMeta
from abc import abstractmethod

class Soda:
		def __init__(self, n, p):
				self.name = n
				self.price = p
				
		def getName(self):
				return self.name

			
class Machine(metaclass = ABCMeta):
		def __init__(self):
				self.sodaList = []
		
		@abstractmethod
		def addSoda(self):
				pass
		
		@abstractmethod
		def removeSoda(self):
				pass


class SodaMachine(Machine):
		def __init__(self, totalMoney):
				self.sodaList = []
				self.totalMoney = totalMoney
		
		def addSoda(self, soda):
				self.sodaList.append(soda)

		def removeSoda(self):
				if len(self.sodaList) > 0:
						print('계산전잔고 : {0} 원'.format(self.totalMoney))
						print('음료수가격 : {0} 원'.format(self.sodaList[0].price))
						self.totalMoney = self.totalMoney - self.sodaList[0].price
						print('계산후잔고 : {0} 원'.format(self.totalMoney))
						self.sodaList.pop(0)


if __name__ == '__main__':
		sodaMachine = SodaMachine(10000);
		print('sodaMachine : {0}'.format(sodaMachine))

		sodaMachine.addSoda(Soda('Cola', 500))
		sodaMachine.addSoda(Soda('Cider', 600))
		sodaMachine.addSoda(Soda('Fanta', 700))
		
		for s in sodaMachine.sodaList:
				print(s.getName())
		
		sodaMachine.removeSoda()
		
		for s in sodaMachine.sodaList:
				print(s.getName())
		
		sodaMachine.addSoda(Soda('Cola', 500))
		sodaMachine.addSoda(Soda('Cola', 500))
		
		for s in sodaMachine.sodaList:
				print(s.getName())