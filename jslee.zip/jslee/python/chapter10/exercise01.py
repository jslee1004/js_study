from sodaMachine01 import machine as m

mySodaMachine = m.SodaMachine(10000);
print('mySodaMachine : {0}'.format(mySodaMachine))

mySodaMachine.addSoda(m.Soda('Cola', 500))
mySodaMachine.addSoda(m.Soda('Cola', 500))
mySodaMachine.addSoda(m.Soda('Cola', 500))
mySodaMachine.addSoda(m.Soda('Cider', 600))
mySodaMachine.addSoda(m.Soda('Cider', 600))
mySodaMachine.addSoda(m.Soda('Fanta', 700))

print('--- mySodaMachine sodaList ---')
for s in mySodaMachine.sodaList:
		print(s.getName())

friendSodaMachine = m.SodaMachine(20000);
print('\nfriendSodaMachine : {0}'.format(friendSodaMachine))

friendSodaMachine.addSoda(m.Soda('Cola-zero', 800))
friendSodaMachine.addSoda(m.Soda('Cola-zero', 800))
friendSodaMachine.addSoda(m.Soda('Cola-zero', 800))
friendSodaMachine.addSoda(m.Soda('Cider-zero', 900))
friendSodaMachine.addSoda(m.Soda('Cider-zero', 900))
friendSodaMachine.addSoda(m.Soda('Fanta-apple', 1000))
friendSodaMachine.addSoda(m.Soda('OranC-orange', 1100))

print('\n--- friendSodaMachine sodaList ---')
for s in friendSodaMachine.sodaList:
		print(s.getName())

print('\n--- mySodaMachine removeSoda ---')
mySodaMachine.removeSoda()

print('\n--- mySodaMachine sodaList ---')
for s in mySodaMachine.sodaList:
		print(s.getName())

print('\n--- friendSodaMachine removeSoda ---')
friendSodaMachine.removeSoda()

print('\n--- friendSodaMachine sodaList ---')
for s in friendSodaMachine.sodaList:
		print(s.getName())

print('\n--- friendSodaMachine removeSoda ---')
friendSodaMachine.removeSoda()

print('\n--- friendSodaMachine sodaList ---')
for s in friendSodaMachine.sodaList:
		print(s.getName())

print('\n--- friendSodaMachine removeSoda ---')
friendSodaMachine.removeSoda()

print('\n--- friendSodaMachine sodaList ---')
for s in friendSodaMachine.sodaList:
		print(s.getName())

print('\n--- friendSodaMachine removeSoda ---')
friendSodaMachine.removeSoda()