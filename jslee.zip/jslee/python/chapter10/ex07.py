from userPackage import calculator

result = calculator.add(10, 20)
print('calculator.add(10, 20) : {0}'.format(result))

result = calculator.sub(10, 20)
print('calculator.sub(10, 20) : {0}'.format(result))