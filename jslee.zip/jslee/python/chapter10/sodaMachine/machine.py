from abc import ABCMeta
from abc import abstractmethod

class Soda:
		def __init__(self, n):
				self.name = n
				
		def getName(self):
				return self.name

			
class Machine(metaclass = ABCMeta):
		def __init__(self):
				self.sodaList = []
		
		@abstractmethod
		def addSoda(self):
				pass
		
		@abstractmethod
		def removeSoda(self):
				pass


class SodaMachine(Machine):
		def __init__(self):
				self.sodaList = []
		
		def addSoda(self, soda):
				self.sodaList.append(soda)

		def removeSoda(self):
				if len(self.sodaList) > 0:
						self.sodaList.pop(0)


if __name__ == '__main__':
		sodaMachine = SodaMachine();
		print('sodaMachine : {0}'.format(sodaMachine))

		sodaMachine.addSoda(Soda('Cola'))
		sodaMachine.addSoda(Soda('Cider'))
		sodaMachine.addSoda(Soda('Fanta'))
		
		for s in sodaMachine.sodaList:
				print(s.getName())
		
		sodaMachine.removeSoda()
		
		for s in sodaMachine.sodaList:
				print(s.getName())
		
		sodaMachine.addSoda(Soda('Cola'))
		sodaMachine.addSoda(Soda('Cola'))
		
		for s in sodaMachine.sodaList:
				print(s.getName())