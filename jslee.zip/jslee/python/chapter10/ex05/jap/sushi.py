def makeSushi():
		print(' --- makeSushi() --- ')