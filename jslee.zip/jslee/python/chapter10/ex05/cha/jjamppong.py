def makeJjamppong():
		print(' --- makeJjamppong() --- ')