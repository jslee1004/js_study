def makeJjajang():
		print(' --- makeJjajang() --- ')