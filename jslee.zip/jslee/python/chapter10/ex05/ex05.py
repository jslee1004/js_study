from kor import gimchi
from kor import gimbap

from cha import jjajang
from cha import jjamppong

from jap import sushi
from jap import udon

if __name__ == '__main__':
		print('\n --- KOREA FOOD ---')
		gimchi.makeGimchi()
		gimbap.makeGimbap()
		
		print('\n --- CHINA FOOD ---')
		jjajang.makeJjajang()
		jjamppong.makeJjamppong()
		
		print('\n --- JAPAN FOOD ---')
		sushi.makeSushi()
		udon.makeUdon()