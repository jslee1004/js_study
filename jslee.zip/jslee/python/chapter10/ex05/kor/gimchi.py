def makeGimchi():
		print(' --- makeGimchi() --- ')