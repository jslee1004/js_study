def addition(n1, n2):
    print('덧셈 연산 결과 : {0}'.format(int(n1) + int(n2)))
    return

def subtraction(n1, n2):
    print('뺄셈 연산 결과 : {0} '.format(int(n1) - int(n2)))
    return
			
def multiplication(n1, n2):
    print('곱셈 연산 결과 : {0} '.format(int(n1) * int(n2)))
    return
			
def division(n1, n2):
    print('나눗셈 연산 결과 : {0} '.format(int(n1) / int(n2)))
    return
		
def rest(n1, n2):
    print('나머지 연산 결과 : {0} '.format(int(n1) % int(n2)))
    return
		
def portion(n1, n2):
    print('몫 연산 결과 : {0} '.format(int(n1) // int(n2)))
    return