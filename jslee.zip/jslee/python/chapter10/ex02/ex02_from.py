from calculator import addition
from calculator import subtraction

addition(10, 20)
subtraction(10, 20)
#multiplication(10, 20)
#division(10, 20)
#rest(10, 20)
#portion(10, 20)