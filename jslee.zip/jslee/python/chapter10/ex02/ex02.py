'''import calculator

calculator.addition(10, 20)
calculator.subtraction(10, 20)
calculator.multiplication(10, 20)
calculator.division(10, 20)
calculator.rest(10, 20)
calculator.portion(10, 20)'''


import calculator as c

c.addition(10, 20)
c.subtraction(10, 20)
c.multiplication(10, 20)
c.division(10, 20)
c.rest(10, 20)
c.portion(10, 20)