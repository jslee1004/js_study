if __name__ == '__main__':
		print('This is tempModule03.')
		print('__name__ : {0}'.format(__name__))