if __name__ == '__main__':
		print('This is tempModule02.')
		print('__name__ : {0}'.format(__name__))