import tempModule01
import tempModule02
import tempModule03

if __name__ == '__main__':
		print('This is ex04.')
		print('__name__ : {0}'.format(__name__))