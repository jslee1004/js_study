import tempModule as t

print('This is ex03.')

t.tempFun1()
t.tempFun2()
