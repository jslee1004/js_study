print('This is tempModule.')

def tempFun1():
		print('--- tempFun1() ---')

def tempFun2():
		print('--- tempFun2() ---')