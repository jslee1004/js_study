from sodaMachine import machine as m

mySodaMachine = m.SodaMachine();
print('mySodaMachine : {0}'.format(mySodaMachine))

mySodaMachine.addSoda(m.Soda('Cola'))
mySodaMachine.addSoda(m.Soda('Cola'))
mySodaMachine.addSoda(m.Soda('Cola'))
mySodaMachine.addSoda(m.Soda('Cider'))
mySodaMachine.addSoda(m.Soda('Cider'))
mySodaMachine.addSoda(m.Soda('Fanta'))
		
for s in mySodaMachine.sodaList:
		print(s.getName())

friendSodaMachine = m.SodaMachine();
print('friendSodaMachine : {0}'.format(friendSodaMachine))

friendSodaMachine.addSoda(m.Soda('Cola-zero'))
friendSodaMachine.addSoda(m.Soda('Cola-zero'))
friendSodaMachine.addSoda(m.Soda('Cola-zero'))
friendSodaMachine.addSoda(m.Soda('Cider-zero'))
friendSodaMachine.addSoda(m.Soda('Cider-zero'))
friendSodaMachine.addSoda(m.Soda('Fanta-apple'))
friendSodaMachine.addSoda(m.Soda('OranC-orange'))
		
for s in friendSodaMachine.sodaList:
		print(s.getName())

mySodaMachine.removeSoda()
for s in mySodaMachine.sodaList:
		print(s.getName())

friendSodaMachine.removeSoda()
for s in friendSodaMachine.sodaList:
		print(s.getName())