class1 = ("정우람", "박으뜸", "배힘찬")
print(class1)

print(class1[0])
print(class1[1])
print(class1[2])

length = len(class1)
print(length)

class2 = ("박찬호", "이승엽", "이병규")

classSum = class1 + class2
print(type(classSum))
print(classSum)

# 데이터 슬라이싱
print(classSum)
print(classSum[:3])
print(classSum[1:4])
print(classSum[len(classSum)-3:])

# index() 메서드
indexNum = classSum.index("박찬호")
print(type(indexNum))
print(indexNum)

# count() 메서드
class3 = ("정우람", "박으뜸", "배힘찬", "정우람", "이승엽", "배힘찬")
print(class3)

num = class3.count("정우람")
print(num)

num = class3.count("박으뜸")
print(num)

num = class3.count("배힘찬")
print(num)