# 딕셔너리 생성
dicVar1 = {10:'정우람', 20:'박으뜸', 30:'배힘찬', 40:'천영웅', 50:'신석기'}

print(dicVar1)
print(dicVar1[10])
print(dicVar1[20])
print(dicVar1[30])
print(dicVar1[40])
print(dicVar1[50])

# 딕셔너리 생성
dicVar2 = {}

# 데이터 추가
dicVar2['정우람'] = 30
dicVar2['박으뜸'] = 26
dicVar2['배힘찬'] = 31
dicVar2['천영웅'] = 28
dicVar2['신석기'] = 25

print(dicVar2)

# 데이터 참조 및 수정
print(dicVar2['천영웅'])
print(dicVar2['배힘찬'])
print(dicVar2['신석기'])

dicVar2['천영웅'] = 31
dicVar2['배힘찬'] = 32
dicVar2['신석기'] = 26

print(dicVar2['천영웅'])
print(dicVar2['배힘찬'])
print(dicVar2['신석기'])

# 데이터 삭제
print(dicVar2)
del dicVar2['정우람']
print(dicVar2)

# 데이터 개수 확인
print(len(dicVar2))


