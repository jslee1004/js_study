students = ["정우람", "박으뜸", "배힘찬", "천영웅", "신석기", "배민규", "전민수", "박건우", "박찬호", "이승엽"]

# 전체학생명단
print(students)

# 학생개인이름
print(students[0])
print(students[1])
print(students[2])
print(students[3])

# 전체 학생수
print(len(students))