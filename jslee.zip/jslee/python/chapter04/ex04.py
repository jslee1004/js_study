# 시나리오 1
students = ["정우람", "박으뜸", "배힘찬", "천영웅", "신석기", "배민규", "전민수", "박건우", "박찬호", "이승엽"]
print(students)

# 시나리오 2
students.sort()
print(students)

# 시나리오 3
students.remove("박찬호")
print(students)
print(len(students))

# 시나리오 4
print(students[:3])

# 시나리오 5
students.append("이병규")
students.sort()
print(students)

# 시나리오 6
students.reverse()
print(students)

# 시나리오 7
ind = students.index("정우람")
students[ind] = "정잘남"
print(students)
