total = 0

myStationery = {}
myStationery["지우개"] = 5
myStationery["연필"] = 10
myStationery["색연필"] = 20
myStationery["공책"] = 10
myStationery["필통"] = 2

print(myStationery)
print(myStationery.keys())
print(myStationery.values())

# 지우개 1개를 다 썼음
myStationery["지우개"] = myStationery["지우개"] - 1
print(myStationery["지우개"])

total = myStationery["지우개"] + myStationery["연필"] + myStationery["색연필"] + myStationery["공책"] + myStationery["필통"]
print("total : ", total, '개')

# 연필 2자루를 잃어버렸음
myStationery["연필"] = myStationery["연필"] - 2
print(myStationery["연필"])

total = myStationery["지우개"] + myStationery["연필"] + myStationery["색연필"] + myStationery["공책"] + myStationery["필통"]
print("total : ", total, '개')

# 공책 2권을 선물 받았음
myStationery["공책"] = myStationery["공책"] + 2
print(myStationery["공책"])

total = myStationery["지우개"] + myStationery["연필"] + myStationery["색연필"] + myStationery["공책"] + myStationery["필통"]
print("total : ", total, '개')