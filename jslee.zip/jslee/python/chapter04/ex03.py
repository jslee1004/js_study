listVar1 = [123, 3.14, "파이썬"]

print(listVar1)

print(listVar1[0])
print(listVar1[1])
print(listVar1[2])

# 데이터 추가
listVar1.append("python")
print(listVar1)

# 데이터 삭제
listVar1.pop()
print(listVar1)

# 특정 인덱스의 데이터 삭제
listVar1.pop(1)
print(listVar1)

# 리스트 길이
print(len(listVar1))

# 리스트 연장
listVar2 = ["c", "c++", "java"]

listVar1.extend(listVar2)
print(listVar1)

# 특정 위치에 데이터 삽입
listVar1.insert(2, "program")
print(listVar1)

# 특정 데이터 삭제하기
listVar1.remove("c")
print(listVar1)
listVar1.remove("c++")
print(listVar1)

# 특정 데이터가 여러개인 경우 삭제하기
listVar3 = ["c", "c++", "java", "c", "c++"]
print(listVar3)

listVar3.remove("c")
print(listVar3)

# 데이터 정렬
listVar4 = [4, 1, 5, 2, 3]
print(listVar4)

listVar4.sort(reverse = False)
print(listVar4)

listVar4.sort(reverse = True)
print(listVar4)

# 데이터 역순
listVar5 = ["c", "c++", "c#", "java", "python"]
print(listVar5)

listVar5.reverse()
print(listVar5)

listVar5.reverse()
print(listVar5)

# 데이터 슬라이싱
listVar6 = ["호랑이", "사자", "곰", "여우", "늑대"]
print(listVar6)

# 앞에서 3개의 데이터 추출
print(listVar6[:3])

# 중간에서 3개의 데이터 추출
print(listVar6[1:4])

# 뒤에서 3개의 데이터 추출
print(listVar6[len(listVar6)-2:])