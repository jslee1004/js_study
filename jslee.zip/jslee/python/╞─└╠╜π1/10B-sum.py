s = 0

x = 1

while x <= 10:

    s = s + x

    print("x:", x, "sum:", s)

    x = x + 1
