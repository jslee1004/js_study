def square(a):       #a의 제곱을 구하는 함수

    c = a * a

    return c

def triangle(a, h):      #삼각형 넓이 구하는 공식

    c = a * h /2

    return c

s1 = 4

s2 = square(s1)                  #s1(4)의 제곱을 구하는 함수를 호출해 결과를 s2에 저장

print (s1, s2)

print (triangle(3, 4))     #삼각형의 넓이를 출력
