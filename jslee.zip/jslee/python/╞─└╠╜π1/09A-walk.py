import turtle as t

import random

t.shape("turtle")                    #거북이 모양 거북이 그래픽 사용


t.speed(0)


for x in range(500):                    #거북이 500번 움직임

    a = random.randint(1, 360)                    #1~360중 아무 수를 골라 a에 저장

    b = random.randint(1, 100)                    #1~100중 아무 수를 골라 b에 저장

    t.setheading(a)                    #거북이방향을 a각도로 변경

    t.forward(b)                    #거북이 b만큼 앞으로 이동
