import random

a = random.randint(1, 30)       #a에 1~30사이의 임의의 수를 저장


b = random.randint(1, 30)       #a에 1~30사이의 임의의 수를 저장


print(a, "+", b, "=")       #문제를 출제


x = input()       #답을 받고 x에 저장


c = int(x)       #x를 정수로 전환

if a+b  == c:

    print("천재")

else:

    print("바보")

    
