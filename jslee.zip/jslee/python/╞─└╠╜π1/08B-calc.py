x = input("12+23 = ")   #문제를 보여주고 답을 입력받아 x에 저장(문자열임)

a = int(x)             #숫자를 비교할수있게 x에 저장된 문자열을 정수로 변환float는 소수 str문자열

if a == 12+23:

    print("천재")

else:

    print("바보")
    
