def hello():

    print("Hello Python!")


hello()

hello()

hello()
