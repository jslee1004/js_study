def sum_func(n):

    s = 0                        #합을 구하기 위한 변수 s(시작 값을 0으로 지정)

    for x in range(1, n+1):     #1~n 까지 반복 n+1은 제외

        s = s + x            #s 값에 x를 더해서 다시 s에 저장

    return s             #계산된 s값을 결과값으로 돌려준다.

print(sum_func(10))

print(sum_func(100))

print(sum_func(1000))
