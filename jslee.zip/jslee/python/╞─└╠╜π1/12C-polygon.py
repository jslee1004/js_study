import turtle as t

def polygon(n):

    for x in range(n):          #n번 반복

        t.forward(50)           #50만큼 이동

        t.left(360/n)           #n360/n번만큼 왼쪽회전



def polygon2(n, a):

    for x in range(n):           #n번 반복

        t.forward(a)            #a만큼 앞으로 이동

        t.left(360/n)           #360/n만큼 왼쪽회전



polygon(3)

polygon(5)


#그림 안그리고 100만큼 이동

t.up()
t.forward(100)
t.down()



polygon2(3, 75)

polygon2(5, 100)
