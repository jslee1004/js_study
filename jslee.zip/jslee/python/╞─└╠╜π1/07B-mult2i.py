x = input("?")  #변수 x에 첫 번째 입력을 받는다. x=문자열

a = float(x)      #문자열 x의 값을 정수(int)로 봐꿔서 a에 넣는다.



x = input("?")  #변수 x에 첫 번째 입력을 받는다. x=문자열

b = float(x)      #문자열 x의 값을 정수(int)로 봐꿔서 b에 넣는다.

print(a*b)


