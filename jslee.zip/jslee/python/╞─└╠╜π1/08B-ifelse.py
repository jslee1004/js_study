a = 3               #변수 a에 3을 저장

if a == 2:          # a가 2와 같은지 비교
    
    print("A")      #false이므로 실행 X

if a == 3:          # a가 3와 같은지 비교
    
    print("B")      #ture이므로 실행

if a ==4:          # a가 4와 같은지 비교

    print("C")      #false이므로 실행 X
 
else:               

    print("D")      #printC 대신 실행
