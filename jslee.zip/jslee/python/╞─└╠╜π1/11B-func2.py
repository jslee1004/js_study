def hello(name):

    print("Hello", name)


hello("jun")

hello("sub")

hello("lee")
