name = input("Your name?")
print("Hello", name)
