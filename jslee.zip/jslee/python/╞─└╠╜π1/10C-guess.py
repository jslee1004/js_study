import random

n = random.randint(1, 30)     #1~30사이의 임의수를 뽑는다.



while True:             #영원히 반복

    x = input("맞혀 보세요")

    g = int(x)

    if g == n:

        print("정답")

        break

    if g < n:
        
        print("작아요")

    if g > n:

        print("커요")
        
