def factorial(n):

    fact = 1                    #곱을 구하기 위한 변수 fact(시작 값을 1으로 지정)

    for x in range(1, n+1):     #1~n 까지 반복 n+1은 제외

        fact = fact * x            #fact 값에 x를 곱해서 다시 fact에 저장

    return fact             #계산된 fact값을 결과값으로 돌려준다.

print(factorial(5))

print(factorial(10))

print(factorial(15))
